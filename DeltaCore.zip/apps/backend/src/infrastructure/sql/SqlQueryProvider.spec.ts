import path from "node:path";
import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { SqlQueryProvider } from "../sql/SqlQueryProvider.js";
import type { ITextFileReader } from "../../domain/ports/ITextFileReader.js";

class InMemorySqlFiles implements ITextFileReader {
  constructor(private readonly files: Record<string, string>) {}

  readTextSync(absolutePath: string): string {
    const key = absolutePath.replaceAll("\\", "/");
    const hit = Object.entries(this.files).find(([file]) => key.endsWith(file));
    if (!hit) {
      throw new Error(`SQL file not found: ${absolutePath}`);
    }
    return hit[1];
  }
}

describe("SqlQueryProvider", () => {
  it("interpolates {{variables}} from a dialect feature file", () => {
    const files = new InMemorySqlFiles({
      "db2/schema-compare.sql":
        "SELECT * FROM SYSCAT.COLUMNS WHERE TABSCHEMA = '{{schema}}'",
    });
    const provider = new SqlQueryProvider("/virtual/sql-dialects", files);

    const sql = provider.buildQuery("db2", "schema-compare", { schema: "QGPL" });

    expect(sql).toContain("TABSCHEMA = 'QGPL'");
    expect(sql).not.toContain("{{");
  });

  it("rejects missing placeholders without a live database", () => {
    const files = new InMemorySqlFiles({
      "oracle/volume-compare.sql": "SELECT '{{missing}}' FROM dual",
    });
    const provider = new SqlQueryProvider("/virtual/sql-dialects", files);

    expect(() => provider.buildQuery("oracle", "volume-compare", {})).toThrow(
      /Missing SQL variables/,
    );
  });

  it("resolves paths as <engine>/<feature>.sql", () => {
    const seen: string[] = [];
    const files: ITextFileReader = {
      readTextSync(absolutePath) {
        seen.push(absolutePath);
        return "SELECT 1";
      },
    };
    const root = path.join("/repo", "sql-dialects");
    new SqlQueryProvider(root, files).buildQuery("sqlserver", "schema-compare", {});
    expect(seen[0]).toBe(path.join(root, "sqlserver", "schema-compare.sql"));
  });

  it("loads db2-ibmi when DB2_CATALOG=ibmi", () => {
    const previous = process.env.DB2_CATALOG;
    process.env.DB2_CATALOG = "ibmi";
    const files = new InMemorySqlFiles({
      "db2-ibmi/list-schemas.sql": "SELECT '{{schemaList}}' FROM QSYS2.SYSSCHEMAS",
    });
    const sql = new SqlQueryProvider("/virtual/sql-dialects", files).buildQuery(
      "db2",
      "list-schemas",
      { schemaList: "'AZBASWQA'" },
    );
    expect(sql).toContain("QSYS2.SYSSCHEMAS");
    if (previous === undefined) {
      delete process.env.DB2_CATALOG;
    } else {
      process.env.DB2_CATALOG = previous;
    }
  });

  it("loads Db2 for i primary keys through SYSCST and SYSKEYCST", () => {
    const previous = process.env.DB2_CATALOG;
    process.env.DB2_CATALOG = "ibmi";
    try {
      const primaryKeySql = readFileSync(
        new URL("../sql-dialects/db2-ibmi/primary-key.sql", import.meta.url),
        "utf8",
      );
      const files = new InMemorySqlFiles({
        "db2-ibmi/primary-key.sql": primaryKeySql,
      });
      const sql = new SqlQueryProvider("/virtual/sql-dialects", files).buildQuery(
        "db2",
        "primary-key",
        { schema: "AZBASWQA", tableName: "ACCTX" },
      );

      expect(sql).toContain("QSYS2.SYSKEYCST K");
      expect(sql).toContain("JOIN QSYS2.SYSCST C");
      expect(sql).toContain("C.CONSTRAINT_TYPE = 'PRIMARY KEY'");
      expect(sql).toContain("ORDER BY K.ORDINAL_POSITION");
      expect(sql).not.toContain("K.CONSTRAINT_TYPE");
    } finally {
      if (previous === undefined) {
        delete process.env.DB2_CATALOG;
      } else {
        process.env.DB2_CATALOG = previous;
      }
    }
  });
});
